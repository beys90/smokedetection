#include <iostream>  
#include <string>  
#include <list>  
#include <vector>  
#include <map>  
#include <map>  
#include <stack>  
  
#include <opencv2/imgproc/imgproc.hpp>  
#include <opencv2/highgui/highgui.hpp>
 
using namespace std;
using namespace cv;
// connetected component labelling using two-pass and seed-filling method
 
class CCL
{
public:
	void icvprCcaByTwoPass(const cv::Mat& _binImg, cv::Mat& _lableImg); 
	void icvprCcaBySeedFill(const cv::Mat& _binImg, cv::Mat& _lableImg); 
	void icvprLabelColor(const cv::Mat& _labelImg, cv::Mat& _colorLabelImg);  
private:

};
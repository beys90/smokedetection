#include<opencv2\legacy\legacy.hpp> 
#include <iostream>
#include <fstream>
#include <string> 
#include <stdio.h>
#include <cv.h>
#include "highgui.h"
#include "LBP.h"
#include "character.h"
#include "foreGround.h"

#include "opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <math.h>
#include <vector>
#include "WriteData.h"


using namespace std;
using namespace cv;
#include "GLCM.h"  
#include <iostream>  
  
using namespace cv;  
using namespace std;  
  
int GLCM::getImage(IplImage* pimg)  
{  
    if (!(pimg->imageData))  
    {  
        return -1;  
    }  
    imageData = (unsigned char*)pimg->imageData;  
    imageDepth = pimg->depth;  
    imageWidth = pimg->width;  
    imageWidthStep = pimg->widthStep;  
    imageHeight = pimg->height;  
    return 0;  
}  
int GLCM::calImageGLCM(GLCMdirEnum direction,int distance,int newgraydepth)  
{  
    if (direction>4||direction<1)  
    {  
        cout<<"entry a direction value between 1 to 4"<<endl;  
        return -1;  
    }  
    if (newgraydepth>imageDepth||newgraydepth<1)  
    {  
        cout<<"entry a bitdepth value between 1 to origin image bitdepth"<<endl;  
        return -1;  
    }  
    int nextpixeloffset;  
    int rowrange[2], colrange[2];  
    rowrange[0] = colrange[0] = 0;  
    rowrange[1] = imageHeight-1, colrange[1] = imageWidth-1;  
    switch (direction)  
    {  
    case horizonal://0��  
        nextpixeloffset = distance;  
        colrange[1] -= distance;  
        break;  
    case vertical://90��  
        nextpixeloffset = - (distance * imageWidthStep);  
        rowrange[0] += distance;  
        break;  
    case diagonal://45��  
        nextpixeloffset = - (distance * imageWidthStep) + distance;  
        rowrange[0] += distance;  
        colrange[1] -= distance;  
        break;  
    case antidiagonal://135��  
        nextpixeloffset = - (distance * imageWidthStep) - distance;  
        rowrange[0] += distance;  
        colrange[0] += distance;  
        break;  
    default:  
        break;  
    }  
  
    //����Ҷȹ�������  
 //   unsigned int glcm8U[256][256]={0};  
	float glcm8U[256][256]={0}; 
    int ipixel,jpixel;  
    for (jpixel=rowrange[0];jpixel<=rowrange[1];jpixel++)  
    {  
        for (ipixel=colrange[0];ipixel<=colrange[1];ipixel++)  
        {  
            int pixelpos = jpixel*imageWidthStep+ipixel;  
            glcm8U[imageData[pixelpos]][imageData[pixelpos+nextpixeloffset]]++;  
        }  
    }  
    initGLCM(newgraydepth);  
    int nsubmatsize = 256/GLCMheight;  
    int imatsize,jmatsize,isubmatsize,jsubmatsize;  
    for (imatsize=0;imatsize<GLCMheight;imatsize++)  
    {  
        for (jmatsize=0;jmatsize<GLCMheight;jmatsize++)  
        {  
            for (isubmatsize=0;isubmatsize<nsubmatsize;isubmatsize++)  
            {  
                for (jsubmatsize=0;jsubmatsize<nsubmatsize;jsubmatsize++)  
                {  
                    GLCMdata[imatsize][jmatsize] += glcm8U[imatsize*nsubmatsize+isubmatsize][jmatsize*nsubmatsize+jsubmatsize];  
                }  
            }  
        }  
    }  
   //GLCM ���ݹ�һ��
	float glcm_sum=0;
	for (imatsize=0;imatsize<GLCMheight;imatsize++)  
    {  
        for (jmatsize=0;jmatsize<GLCMheight;jmatsize++)  
        {  
            if (GLCMdata[imatsize][jmatsize]>0)  
            { 
				glcm_sum+=GLCMdata[imatsize][jmatsize];
			}
		}
	}
		

    //���㲿������ֵ  
    GLCMenergy = 0, GLCMcontrast = 0, GLCMmaxprobability = 0;  
    GLCMentropy = 0 , GLCMIDM = 0;  
    GLCMstdeviation = 0, GLCMcorrelation = 0;//δ�����ֵ  
    for (imatsize=0;imatsize<GLCMheight;imatsize++)  
    {  
        for (jmatsize=0;jmatsize<GLCMheight;jmatsize++)  
        {  
            if (GLCMdata[imatsize][jmatsize]>0)  
            {  
                GLCMdata[imatsize][jmatsize]=GLCMdata[imatsize][jmatsize]/glcm_sum;
				GLCMenergy += GLCMdata[imatsize][jmatsize] * GLCMdata[imatsize][jmatsize];//����  
                GLCMcontrast += (imatsize-jmatsize)*(imatsize-jmatsize)*GLCMdata[imatsize][jmatsize];//�Աȶ�  
                GLCMmaxprobability = GLCMmaxprobability > GLCMdata[imatsize][jmatsize] ? GLCMmaxprobability : GLCMdata[imatsize][jmatsize];//������  
                GLCMentropy += static_cast<double>(-GLCMdata[imatsize][jmatsize]) * std::log(GLCMdata[imatsize][jmatsize]);  //�� 
                if (imatsize!=jmatsize)  
                {  
                    GLCMIDM += static_cast<double>(GLCMdata[imatsize][jmatsize])/(1+(imatsize-jmatsize)*(imatsize-jmatsize));   //���ء�ͬ����
                }  
            }            
        }  
    }  
    return 0;  
}  
  
int GLCM::initGLCM(int newgraydepth)  
{//��ʼ���Ҷȹ���������Ҫ���8*8����newgraydepth����3,16*16��newgraydepthΪ4  
    GLCMheight = std::pow(2,newgraydepth);  
   // GLCMdata = new unsigned int*[GLCMheight];  
	GLCMdata = new float*[GLCMheight]; 
    for (int imat=0;imat<GLCMheight;imat++)  
    {  
     //   GLCMdata[imat] = new unsigned int[GLCMheight];
	//	 memset(GLCMdata[imat],0,GLCMheight*sizeof(unsigned int));  
		GLCMdata[imat] = new float[GLCMheight];  
        memset(GLCMdata[imat],0,GLCMheight*sizeof(float));  
    }  
    return 0;  
}  
  
int GLCM::releaseGLCM()  
{  
    for (int imat=0;imat<GLCMheight;imat++)  
    {  
        delete[] GLCMdata[imat];  
    }  
    delete[] GLCMdata;  
    return 0;  
}  
  
int GLCM::printGLCM()  
{  
    for (int i=0;i<GLCMheight;i++)  
    {  
        for (int j=0;j<GLCMheight;j++)  
        {  
            cout<<GLCMdata[i][j]<<"\t";  
        }  
        cout<<endl;  
    }  
    return 0;  
}  
#include <cv.h>  
enum GLCMdirEnum  
{  
    horizonal = 1,//0��  
    vertical = 2,//90��  
    diagonal = 3,//45��  
    antidiagonal = 4//135��  
};  
class GLCM  
{  
private:  
  //  unsigned int** GLCMdata;  
	float** GLCMdata;  
    unsigned char* imageData;  
    int imageWidth,imageWidthStep,imageHeight,imageDepth,GLCMheight;  
public:  
    //unsigned int GLCMenergy,GLCMcontrast,GLCMmaxprobability,GLCMstdeviation;  
	float GLCMenergy,GLCMcontrast,GLCMmaxprobability,GLCMstdeviation; 
    double GLCMentropy,GLCMIDM,GLCMcorrelation;  
    int getImage(IplImage* pimg);  
    int calImageGLCM(GLCMdirEnum direction,int distance,int newgraydepth);  
    int initGLCM(int newgraydepth);  
    int releaseGLCM();  
    int printGLCM();  
}; 
#include <iostream>  
#include <fstream>  
#include <iterator>  
#include <vector> 
#include "opencv2/opencv.hpp"
#include<vector>
using namespace std;
using namespace cv;
class LoadFile
{
public:
	int LoadDataToMat(string fileName, cv::Mat& matData, int matRows, int matCols, int matChns)  ;
private:

};
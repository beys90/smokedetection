#include <iostream>  
#include <fstream>  
#include <iterator>  
#include <vector> 
#include "opencv2/opencv.hpp"
#include<vector>
using namespace std;
using namespace cv;

class WriteData
{
public:
	int WriteDataFromMat(string fileName, cv::Mat& matData);  
	int WriteDataFromLabel(string filename,vector<int> data);
private:

};
// #include "stdafx.h"  
#include "Character.h"  
  
ImageProcess::ImageProcess()  
    :m_binaryImg(NULL)  
{  
  
}  
  
ImageProcess::~ImageProcess()  
{  
    if (m_binaryImg != NULL)  
    {  
        cvReleaseImage(&m_binaryImg);  
        m_binaryImg = NULL;  
    }  
}  
  
IplImage* ImageProcess::loadImage(const char* fileName, unsigned colorMode /* = 1 */)  
{  
    return cvLoadImage(fileName, colorMode);  
}  
  
  
IplImage* ImageProcess::binaryImg(IplImage* img, unsigned threshold, int thresholdType)  
{  
#ifdef _DEBUG  
    assert(img != NULL);  
    assert((img->nChannels == 1) || (img->nChannels == 3));  
    assert((threshold >= 0) && (threshold <= 255));  
#endif  
  
    m_binaryImg = cvCreateImage(cvGetSize(img), img->depth, 1);  
  
    if (img->nChannels == 1)  
    {  
        cvThreshold(img, m_binaryImg, threshold, 255, thresholdType);  
    }  
    else  
    {  
        IplImage* rImg = cvCreateImage(cvGetSize(img), img->depth, 1);  
        cvSplit(img, NULL, NULL, rImg, NULL);  
        cvThreshold(rImg, m_binaryImg, threshold, 255, thresholdType);  
  
        if (rImg != NULL)  
        {  
            cvReleaseImage(&rImg);  
        }  
    }  
  
    IplConvKernel* element = cvCreateStructuringElementEx(5, 5, 2, 2, CV_SHAPE_ELLIPSE);  
    cvSmooth(m_binaryImg, m_binaryImg, CV_MEDIAN);  
    cvErode(m_binaryImg, m_binaryImg, element, 1);  
    cvDilate(m_binaryImg, m_binaryImg, element, 1);  
    cvReleaseStructuringElement(&element);  
  
    return m_binaryImg;  
  
}  
  
Character::Character()  
    : m_nArea(0)  
{  
  
}  
  
Character::~Character()  
{  
  
}  
  
CvSeq* Character::getMaxAreaContour(CvSeq* seq)  
{  
#ifdef _DEBUG  
    assert(seq != 0);  
#endif  
  
    CvSeq* maxSeq = 0;  
  
    for (CvSeq* c = seq; c != NULL; c = c->h_next)  
    {  
        float area = fabs(cvContourArea(c, CV_WHOLE_SEQ));  // get area of contours  
  
        if (m_nArea < area)  
        {  
            maxSeq = c;  
        }  
    }  
  
    return maxSeq;  
}  
  
// ����ͼ������  
CvSeq* Character::findImgContours(IplImage* img, CvMemStorage* storage)  
{  
    if (img->nChannels != 1)  
        return NULL;  
  
    CvSeq *seq = 0;  
    cvFindContours(img, storage, &seq, sizeof(CvContour),   
        CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);    // ��������  
      
    for (; seq != 0; seq = seq->h_next)  
    {  
        m_seq = getMaxAreaContour(seq);  
    }  
  
    return m_seq;  
}  

// /*
// ����Ŀ������ľ�ֵ�ͷ���  
void Character::calAvgSdv(IplImage* img, CvSeq* seq, cv::Scalar *ave, cv::Scalar *sdv)  
{  
    IplImage* bitImg = getBinaryImg();  
  
    CvRect rect = { 0 };  
    for (; seq != 0; seq = seq->h_next)  
    {  
        // ������ֵͼ�������  
        cvDrawContours(bitImg, seq, cvScalarAll(255), cvScalarAll(255),  
            -1, CV_FILLED, 8);  
        rect = cvBoundingRect(seq, 0);  
    }  
  
    if (img->nChannels == 1)     // ����ǵ�ͨ��ͼ��  
    {  
        vector<double> vec;  
  
        for (int i = rect.x; i < rect.x + rect.width; ++i)  
        {  
            for (int j = rect.y; j < rect.y + rect.height; ++j)  
            {  
                CvScalar s = cvGet2D(bitImg, j, i);  
                if (s.val[0] == 255)  
                {  
                    s = cvGet2D(img, j, i);  
                    vec.push_back(s.val[0]);  
                }  
            }  
  
        } // end for i  
  
        // �����ֵ  
        if (ave != NULL)  
        {  
            if (!vec.empty())  
            {  
                ave->val[0] = (double)(accumulate(vec.begin(), vec.end(), 0))  
                    / vec.size();  
            }  
        }  
  
        // ���㷽��  
        if (sdv != NULL)  
        {  
            if (! vec.empty())  
            {  
                double sum = 0.0;  
                for_each(vec.begin(), vec.end(), [&](const double d)  
                {  
                    sum += pow((d - ave->val[0]), 2);  
                });  
                sdv->val[0] = sqrt(sum / vec.size());  
            }  
              
              
        }  
  
    }// end if img->nChannel == 1  
  
    if (img->nChannels == 3)  // ���ͼ��Ϊ 3 ͨ��ͼ��  
    {  
        vector<double> vec[3];  
  
        for (int i = 0; i < rect.x + rect.width; ++i)  
        {  
            for (int j = 0; j < rect.y + rect.height; ++j)  
            {  
                CvScalar s = cvGet2D(bitImg, j, i);  
                if (s.val[0] == 255)  
                {  
                    s = cvGet2D(img, j, i);  
                    vec[0].push_back(s.val[0]);       
                    vec[1].push_back(s.val[1]);       
                    vec[2].push_back(s.val[2]);       
                }  
            }  
  
        }// end for i  
  
        // �����ֵ  
        if (ave != NULL)  
        {  
            for (int i = 0; i < 3; ++i)  
            {  
                if (! vec[i].empty())  
                {  
                    ave->val[i] = (double)(accumulate(vec[i].begin(), vec[i].end(), 0))  
                        / vec[i].size();  
                }  
            }  
        }// end ave  
  
        if (sdv != NULL)  
        {  
            for (int i = 0; i < 3; ++i)  
            {  
                if (!vec[i].empty())  
                {  
                    double sum = 0.0;  
                    for_each(vec[i].begin(), vec[i].end(), [&](const double d)  
                    {  
                        sum += pow(d - ave->val[i], 2);  
                    });   
  
                    sdv->val[i] = sqrt(sum / vec->size());  
                }     
            }  
        }// end if sdv  
  
    }// end if img->nChannels == 3  
  
  
}  
 
// ����ֱ��ͼ  
template<typename _T>  
void Character::calHist(IplImage* img, CvSeq* seq, _T hist[])  
{  
    IplImage* grayImg = NULL;  
    IplImage* bitImg = getBinaryImg();  
    grayImg = cvCreateImage(cvGetSize(img), IPL_DEPTH_8U, 1);  
  
    if (img->nChannels == 3)  
        cvCvtColor(img, grayImg, CV_RGB2GRAY);  
    else  
        cvCopy(img, grayImg, NULL);  
  
    CvRect rect = { 0 };  
  
    for (; seq != 0; seq = seq->h_next)  
    {  
        cvDrawContours(bitImg, seq, cvScalarAll(255), cvScalarAll(255),  
            -1, CV_FILLED, 8);  
        rect = cvBoundingRect(seq, 0);  
    }  
  
    for (int i = rect.x; i < rect.x + rect.width; ++i)  
    {  
        for (int j = rect.y; j < rect.y + rect.height; ++j)  
        {  
            CvScalar s = cvGet2D(bitImg, j, i);   
            if (s.val[0] == 255)  
            {  
                s = cvGet2D(grayImg, j, i);  
                int val = s.val[0];  
                ++hist[val];  
            }  
        }  
    }  
  
    // �ͷ��ڴ�  
    cvReleaseImage(&grayImg);  
}  
  
// ����ֱ��ͼ��ͳ�Ƴ�����Ƶ����ߵĻҶ�ֵ  
int Character::calHistValue(IplImage* img, CvSeq* seq)  
{  
    int hist[256] = { 0 };  
    calHist(img, seq, hist);  
  
    int maxVal = 0;  
    int grayVal = 0;  
  
    for (int i = 0; i < 256; ++i)  
    {  
        if (maxVal < hist[i])  
        {  
            maxVal = hist[i];  
            grayVal = i;            // ������ָ������ĻҶ�ֵ  
        }  
    }  
  
    return grayVal;  
  
}  

// ����ͼ�����ֵ  
double Character::calEntropy(IplImage* img, CvSeq* seq)  
{  
    // ����ֱ��ͼ  
    double hist[256] = { 0.0 };  
    calHist(img, seq, hist);  
  
    int total = 0;  
    for (int i = 0; i < 256; ++i)  
    {  
        total += hist[i];  
    }  
  
    // ����ÿ���Ҷ�ֵ�ĸ���  
    double temp[256] = { 0.0 };  
    for (int i = 0; i < 256; ++i)  
    {  
        temp[i] = hist[i] / total;  
    }  
  
    // ������Ϣ��  
    double entropy = 0.0;  
    for (int i = 0; i < 256; ++i)  
    {  
        if (temp[i] == 0.0)  
        {  
            entropy = entropy;  
        }  
        else  
        {  
            entropy -= temp[i] * (log(temp[i]) / log(2.0));  
        }  
    }  
      
    return entropy;  
}  
 // */

// ��ȡ��Բ����  
FitEllipse Character::calEllipseCharater(CvSeq* seq)  
{  
    CvBox2D box = { 0 };  
    double area = 0;  
    for (; seq != 0; seq = seq->h_next)  
    {  
        // ���������Բ  
        box = cvFitEllipse2(seq);  
        area = fabs(cvContourArea(seq, CV_WHOLE_SEQ));  
    }  
      
    box.angle = 90 - box.angle;  
    m_ellipse.angle = box.angle;        // ���  
  
    float height = box.size.height;       
    float width = box.size.width;  
  
    // ȡ�ϴ��ֵΪ��Բ�ĳ��᳤,��С��ֵΪ���᳤  
    if (height > width)  
    {  
        m_ellipse.height = height;  
        m_ellipse.width = width;  
    }  
    else  
    {  
        m_ellipse.height = width;  
        m_ellipse.width = height;  
    }  
  
    float a = 0, b = 0;   
    a = m_ellipse.height;   // ���᳤  
    b = m_ellipse.width;    // ���᳤  
  
    // �ܳ�  
    float l = 3.14f * b + 2 * (a - b);  
    m_ellipse.length = l;  
  
    float ellArea = 3.14f * a * b / 4;      // ��Բ���  
    m_ellipse.area = ellArea;  
  
    // ��Բ��϶�  
    float fit = area / ellArea;  
    m_ellipse.fit = fit;  
  
    // ������  
    float c = sqrt((a * a) - (b * b));  
    float e = c / a;  
    m_ellipse.e = e;  
  
    return m_ellipse;  
}  
  
// ������ζ�  
double Character::calRectFit(CvSeq* seq)  
{  
    CvBox2D rect;  
    double area = 0.0;  
    for (; seq != 0; seq = seq->h_next)  
    {  
        rect = cvMinAreaRect2(seq);     // ��С��Ͼ���  
        area = fabs(cvContourArea(seq, CV_WHOLE_SEQ));  
    }  
  
    double rectArea = rect.size.height * rect.size.width;  
  
    double fit = area / rectArea;   // ���ζ�  
  
    return fit;  
}  
  
// ����͹��  
double Character::calHullFit(CvSeq* seq, CvMemStorage* storage)  
{  
    CvSeq* hull = 0;  
    double hullArea = 0.0, area = 0.0;  
  
    for (; seq != 0; seq = seq->h_next)  
    {  
        // �������͹����Σ�����αƽ�  
        //hull = cvApproxPoly(seq, sizeof(CvContour), storage, CV_POLY_APPROX_DP, 3, 1);  
          
        // ͹������С���͹�����  
        hull = cvConvexHull2(seq, 0, CV_CLOCKWISE, 1);  
  
        hullArea = fabs(cvContourArea(hull, CV_WHOLE_SEQ));  
        area = fabs(cvContourArea(seq, CV_WHOLE_SEQ));  
    }  
  
    double fit = area / hullArea;  
  
    return fit;  
}  
  
// ����Ŀ���������  
int Character::calROIArea(IplImage* img,CvSeq* seq)  
{  
    if (img == NULL || img->nChannels != 1)  
        return 0;  
      
    CvRect rect = { 0 };  
    for (; seq != 0; seq = seq->h_next)  
    {  
        cvDrawContours(img, seq, cvScalarAll(255), cvScalarAll(255), -1, CV_FILLED, 8);  
        rect = cvBoundingRect(seq, 0);  
    }  
  
    for (int i = rect.x; i < rect.x + rect.width; ++i)  
    {  
        for (int j = rect.y; j < rect.y + rect.height; ++j)  
        {  
            CvScalar s = cvGet2D(img, j, i);  
            if (s.val[0] == 255)  
            {  
                ++m_nArea;  
            }  
        }  
    }  
  
    return m_nArea;  
  
}  
  
// ����ͼ������  
CvPoint Character::calBaryCentre(IplImage* img,CvSeq* seq)  
{  
    if (img == NULL || img->nChannels != 1)  
        return cvPoint(0, 0);  
      
      
    double m00 = 0.0, m10 = 0.0, m01 = 0.0;  
  
    for (; seq != 0; seq = seq->h_next)  
    {  
        CvMoments moment;  
        cvMoments(img, &moment, 1);  
        m00 = cvGetSpatialMoment(&moment, 0, 0);  
        m10 = cvGetSpatialMoment(&moment, 1, 0);  
        m01 = cvGetSpatialMoment(&moment, 0, 1);  
    }  
  
    // ͼ����������  
    CvPoint pt = { 0 };  
    pt.x =(int)(m10 / m00);  
    pt.y =(int)(m01 / m00);  
  
    return pt;  
}  
  
// ������״����(���ܶ�)  
double Character::calCompactness(CvSeq* seq)  
{  
    double area = 0, length = 0;  
    for (; seq != 0; seq = seq->h_next)  
    {  
        area = fabs(cvContourArea(seq, CV_WHOLE_SEQ));  
        length = cvArcLength(seq, CV_WHOLE_SEQ);  
    }  
  
    double f = (length * length) / (4 * 3.14 * area);  
  
    return f;  
}  
  
// ����ƫ����  
double Character::calEccentricity(CvSeq* seq)  
{  
    CvBox2D rect = { 0 };  
    for (; seq != 0; seq = seq->h_next)  
    {  
        rect = cvMinAreaRect2(seq);     // ��С��Ӿ���  
    }  
  
    double f = 0.0;  
  
    (rect.size.height > rect.size.width)  
        ? (f = rect.size.height / rect.size.width)  
        : (f = rect.size.width / rect.size.height);  
  
    return f;  
  
}  
  
// ����Բ����  
double Character::calCircularity(IplImage* img, CvSeq* seq)  
{  
    if (img == NULL || img->nChannels != 1)  
        return 0.0;  
  
    double m00 = 0.0, m10 = 0.0, m01 = 0.0;  
  
    // ���´������ͼ���Բ����  
    float UR = 0.f; // ���������ĵ��߽���ƽ������  
    float PR = 0.f; // ���������ĵ��߽��ľ���ķ���  
  
  
    for (; seq != 0; seq = seq->h_next)  
    {  
        CvMoments moment;  
        cvMoments(img, &moment, 1);  
        m00 = cvGetSpatialMoment(&moment, 0, 0);  
        m10 = cvGetSpatialMoment(&moment, 1, 0);  
        m01 = cvGetSpatialMoment(&moment, 0, 1);  
  
        // ͼ����������  
        int x = (int)(m10 / m00);  
        int y = (int)(m01 / m00);  
  
        float sum = 0;  
        int count = seq->total;  
        CvPoint* pt;  
        for (int i = 0; i < count; ++i)  
        {  
            pt = (CvPoint*)cvGetSeqElem(seq, i);  
            sum += sqrt(powf(pt->x - x, 2) + powf(pt->y - y, 2));  
        }  
  
        UR = sum / count;  
  
        float tmp = 0.f;  
        sum = 0;  
        for (int i = 0; i < count; ++i)  
        {  
            pt = (CvPoint*)cvGetSeqElem(seq, i);  
            tmp = sqrt(powf(pt->x - x, 2) + powf(pt->y - y, 2));  
            sum += powf(tmp - UR, 2);  
        }  
  
        PR = sum / count;  
  
    }  
  
    // ����Բ����  
    double circularity = UR / PR;  
      
    return circularity;  
}  
  
// ���� 7 �� hu �����  
  
CvHuMoments Character::calHuMoments(CvSeq* seq)  
{  
    CvHuMoments huMoments;  
    for (; seq != 0; seq = seq->h_next)  
    {  
        // ��ȡ7�� hu �����  
        CvMoments moments;  
        cvMoments(seq, &moments, 1);  
        cvGetHuMoments(&moments, &huMoments);  
    }  
  
    return huMoments;  
      
} 
#include "foreGround.h"
#include "character.h"
// background extraction
Mat foreGround::averageFrame(CvCapture *capture, const int frameStart,const int frameEnd)
{
	int frameNumber=frameEnd-frameStart+1;
	Mat img;
	Mat imgGray;
	Mat imgSum;
	for (int i = 0; i < frameNumber; ++i)
	{
		cvSetCaptureProperty(capture,CV_CAP_PROP_POS_FRAMES,frameStart+i);
		img=cvRetrieveFrame(capture);
		cvtColor(img,imgGray,COLOR_BGR2GRAY);
		imgGray.convertTo(imgGray,CV_16U);
		if (i==0)
		{
			imgSum=imgGray.clone();
		//	imgSum.convertTo(imgSum,CV_16U);
		}
		else
			add(imgSum,imgGray,imgSum);
	}
	Mat averageFrame=imgSum/frameNumber;
	averageFrame.convertTo(averageFrame,CV_8U);
	return averageFrame;
}

Mat foreGround::updateBackground(Mat curFrame, Mat backgroundModel, const double coef_ALPHA)
{
		//diff = | frame - backgroundModel |
	Mat imgDiff,maskMotion;
	absdiff(curFrame,backgroundModel,imgDiff);  
	threshold(imgDiff,maskMotion, 30, 255,CV_THRESH_BINARY);

	// 8U -> 32F
	backgroundModel.convertTo(backgroundModel, CV_32F);
	curFrame.convertTo(curFrame,CV_32F);
  //  B( x, y; t+1 ) = ( 1-alpha )B( x, y; t ) + ( alpha )Src( x, y; t ), if the pixel is stationary 
	accumulateWeighted(curFrame,backgroundModel,coef_ALPHA,maskMotion);
  // 32F -> 8U
	backgroundModel.convertTo(backgroundModel,CV_8U);  
	return backgroundModel;

}

//set invalid frame to be zeros
Mat foreGround::frameCrop(Mat frame, vector<CvRect> rects,int blk_width,int blk_height)
{
	Mat frameGrayNew(frame.rows,frame.cols,CV_8U,cv::Scalar(0));   //this matrix is used as a foreground frame to be filetered and dilated
	if (rects.empty()!=1)
	{
		vector<CvRect>::iterator it_rect = rects.begin();
		int origin_x,origin_y,width,height;
		int end_x,end_y;
		while (it_rect!=rects.end())
		{
			origin_x=it_rect->x-blk_width;
			origin_y=it_rect->y-blk_height;				
			width=it_rect->width+2*blk_width;
			height=it_rect->height+2*blk_height;
			end_x=origin_x+width;
			end_y=origin_y+height;
			if (origin_x<0)
				origin_x=0;
			if (origin_y<0)
				origin_y=0;
			if (end_x>frame.cols)
				width=frame.cols-origin_x;
			if (end_y>frame.rows)
				height=frame.rows-origin_y;
			Mat imageROI=frameGrayNew(Rect(origin_x,origin_y,width,height));
			Mat imageROI_pro=frame(Rect(origin_x,origin_y,width,height));
			addWeighted(imageROI,0,imageROI_pro,1,0,imageROI);
			it_rect++;
		}
		return frameGrayNew;
	}
	else
		return frame;
}


// colour filtering by HSV,RGB and YCrCb model
Mat foreGround::ColorDet(Mat srcImg)
{
	Mat m_pcurFrameYCrCb;
	Mat m_pcurFrameHsv;
	double Rt=110;  // threshold ������ֵ
	double St=45;   //
	//double Rth=230;
	//double Gth=230;
	//double Th1=20;
	//double Th2=20;
	//double Th3=15;

	cvtColor(srcImg,m_pcurFrameHsv,CV_BGR2HSV);
	cvtColor(srcImg,m_pcurFrameYCrCb,CV_BGR2YCrCb);

	Mat colorChannels[3],yCrCb[3],hsv[3];
	split(srcImg, colorChannels);
	split(m_pcurFrameYCrCb,yCrCb);
	split(m_pcurFrameHsv,hsv);

	Mat St_matrix(srcImg.rows,srcImg.cols,CV_32F,cv::Scalar(St));
	Mat Rt_matrix(srcImg.rows,srcImg.cols,CV_32F,cv::Scalar(Rt));
	Mat const_255(srcImg.rows,srcImg.cols,CV_8U,cv::Scalar(255));
	Mat S1(srcImg.rows,srcImg.cols,CV_32F,cv::Scalar(0));
	
	subtract(const_255,colorChannels[2],S1);
	S1.convertTo(S1, CV_32F);
	multiply(S1,St_matrix,S1,1,-1);
	divide(S1,Rt_matrix,S1,1,-1);

	// (r>b&&g>b&r>g&&r>=Rt&&s>=s1&&yy>=cb&&cr>=cb)
	Mat comp_rg,comp_rb,comp_gb,comp_rRt,comp_sS1,comp_yyCb,comp_CrCb;
	compare(colorChannels[2],colorChannels[1],comp_rg,CMP_GE);
	compare(colorChannels[1],colorChannels[0],comp_gb,CMP_GE);
//	compare(colorChannels[2],colorChannels[0],comp_rb,CMP_GT);
	Rt_matrix.convertTo(Rt_matrix, CV_8U);
	compare(colorChannels[2],Rt_matrix,comp_rRt,CMP_GE);
	S1.convertTo(S1, CV_8U);
	compare(hsv[1],S1,comp_sS1,CMP_GE);
	compare(yCrCb[0],yCrCb[2],comp_yyCb,CMP_GE);
	compare(yCrCb[1],yCrCb[2],comp_CrCb,CMP_GE);

	Mat comp_dst;
	multiply(comp_rg,comp_gb,comp_dst,1,-1);
//	multiply(comp_dst,comp_rb,comp_dst,1,-1);
	multiply(comp_dst,comp_rRt,comp_dst,1,-1);
	multiply(comp_dst,comp_sS1,comp_dst,1,-1);
	multiply(comp_dst,comp_yyCb,comp_dst,1,-1);
	multiply(comp_dst,comp_CrCb,comp_dst,1,-1);

	threshold(comp_dst, comp_dst, 0, 1, CV_THRESH_BINARY);

	Mat new_Color[3],frame_det;
	multiply(comp_dst,colorChannels[0],new_Color[0],1,-1);
	multiply(comp_dst,colorChannels[1],new_Color[1],1,-1);
	multiply(comp_dst,colorChannels[2],new_Color[2],1,-1);
	merge(new_Color,3,frame_det);

	//cvtColor(frame_det, frame_det, COLOR_BGR2GRAY);
	return frame_det;
}
 
void foreGround::GrayDet(Mat srcImg,int grayThres)
{
	Mat grayImg;
	cvtColor(srcImg,grayImg,COLOR_BGR2GRAY);
	/// �趨bin��Ŀ
	int histSize = 256;
	/// �趨ȡֵ��Χ 
	float range[] = { 0, 256 } ;
	const float* histRange = { range };
	bool uniform = true; bool accumulate = false;
	Mat hist;
	cv::calcHist(&grayImg, 1,0, Mat(),hist, 1, &histSize, &histRange, uniform, accumulate);

	/// ��ֱ��ͼ�����ϻ���ֱ��ͼ
	draw_Histogram(hist,1);
}

void foreGround::draw_Histogram(Mat &hist,int scale)
{  

    int hist_height=256;    
    int bins = 256;  
    double max_val;    
  
    minMaxLoc(hist, 0, &max_val, 0, 0);   
  
    Mat hist_img = Mat::zeros(hist_height,bins*scale, CV_8UC3);    
  
    cout<<"max_val = "<<max_val<<endl;  
    for(int i=0;i<bins;i++)    
    {    
        float bin_val = hist.at<float>(i); //  
  
          
        int intensity = cvRound(bin_val*hist_height/max_val);  //Ҫ���Ƶĸ߶�    
  
        rectangle(hist_img,Point(i*scale,hist_height-1),    
            Point((i+1)*scale - 1, hist_height - intensity),    
            CV_RGB(255,255,255));    
    }  
    namedWindow("Gray Histogram", CV_WINDOW_AUTOSIZE );  
    imshow( "Gray Histogram", hist_img ); 
	waitKey(50);
}

void foreGround::ImgMean(float& c1, float& c2, float& c3, Mat pImg)
{
	int nPixel = pImg.rows*pImg.cols;	// number of pixels in image
	c1 = 0; c2 = 0; c3 = 0;

	//sum up each channel �ۼӸ�ͨ����ֵ
	MatConstIterator_<Vec3b> it = pImg.begin<Vec3b>();
	MatConstIterator_<Vec3b> itend = pImg.end<Vec3b>();

	while (it != itend)
	{
		c1 += (*it)[0];
		c2 += (*it)[1];
		c3 += (*it)[2];
		it++;

	}
	//�ۼӸ�ͨ����ֵ

	c1 = c1 / nPixel;
	c2 = c2 / nPixel;
	c3 = c3 / nPixel;
}

//�����ֵͼ���ش���0�ĸ���
int foreGround::bSums(Mat src)
{
	int counter = 0;
	//�������������ص�
	Mat_<uchar>::iterator it = src.begin<uchar>();
	Mat_<uchar>::iterator itend = src.end<uchar>();
	for (; it != itend; ++it)
	{
		if ((*it)>0) counter += 1;//��ֵ�������ص���0����255
	}
	return counter;
}

//ÿ֡ͼ��ֿ�
vector<FraRIO>  foreGround::DivFra(Mat &image, int width, int height)
{
	char name = 1;
	int m, n;
	m = image.rows / height;
	n = image.cols / width;
	vector<FraRIO> FraRIO_Out;
	FraRIO temFraRIO;
	if (image.channels()==1)
	{
		for (int j = 0; j<m; j++)
		{
			for (int i = 0; i<n; i++)
			{
				Mat temImage(height, width, CV_8U,cv::Scalar(0));
				Mat imageROI = image(Rect(i*width, j*height, temImage.cols, temImage.rows));//rect(x, y, width, height)ѡ������Ȥ����
				addWeighted(temImage, 1.0, imageROI, 1.0, 0.0, temImage);//����ɨ����ı߽�������
			
				temFraRIO.frameRIO = temImage.clone();
				temFraRIO.point_x = i*width;
				temFraRIO.point_y = j*height;
				FraRIO_Out.push_back(temFraRIO);
			}
		}
	}
	if (image.channels()==3)
	{
		for (int j = 0; j<m; j++)
		{
			for (int i = 0; i<n; i++)
			{
				Mat temImage2(height, width, CV_8UC3, cv::Scalar(0, 0, 0));
				Mat imageROI = image(Rect(i*width, j*height, temImage2.cols, temImage2.rows));//rect(x, y, width, height)ѡ������Ȥ����
				addWeighted(temImage2, 1.0, imageROI, 1.0, 0.0, temImage2);//����ɨ����ı߽�������
			
				temFraRIO.frameRIO = temImage2.clone();
				temFraRIO.point_x = i*width;
				temFraRIO.point_y = j*height;
				FraRIO_Out.push_back(temFraRIO);
			}
		}

	}
	return FraRIO_Out;
}

//ÿ֡ͼ��ֿ�
Mat  foreGround::mergeDivFra(vector<FraRIO> frame_RIO, int n, int m)
{
    //m = image_orig.rows / height;
	//n = image_orig.cols / width;
	int height,width;
	int rows,cols;
	height=frame_RIO[0].frameRIO.rows;
	width=frame_RIO[0].frameRIO.cols;
	rows =height*m;;
	cols =width*n;
	Mat image(rows,cols,CV_8U,cv::Scalar(0));
	int index=0;
	for (int j = 0; j<m; j++)
	{
		for (int i = 0; i<n; i++)
		{
			Mat imageROI=image(Rect(i*width, j*height, width,height));
			addWeighted(imageROI,0,frame_RIO[index].frameRIO,1,0,imageROI);
			index++;
		}
	}
	return image;
}

//smoke color detection
Mat foreGround::smokeColorDet(Mat srcImg)
{
	//double Rv=2*20;  // threshold ������ֵ
	double Rv=2*40;	   // threshold ������ֵ
	double I1=40;	   //
	double I2=220;

	Mat colorChannels[3];
	Mat m_pcurI;
	Mat m_pcurGray;
	cvtColor(srcImg,m_pcurGray,CV_BGR2GRAY);
	split(srcImg, colorChannels);

	Mat subBG,subBR,subGR,comp_BG,comp_BR,comp_GR;
	Mat ch1,ch2,ch3;

	colorChannels[0].convertTo(ch1, CV_32F);
	colorChannels[1].convertTo(ch2, CV_32F);
	colorChannels[2].convertTo(ch3, CV_32F);
	//
	subBG=abs(ch1-ch2);
	subBR=abs(ch1-ch3);		
	subGR=abs(ch2-ch3);	

	compare(subBG,Rv,comp_BG,CMP_LE);	
	compare(subBR,Rv,comp_BR,CMP_LE);
	compare(subGR,Rv,comp_GR,CMP_LE);

	Mat comp_I1,comp_I2;
	m_pcurI=(ch1+ch2+ch3)/3;  //80~220
	compare(m_pcurI,I1,comp_I1,CMP_GE);
	compare(m_pcurI,I2,comp_I2,CMP_LE);

	Mat comp_dst;
	multiply(comp_BG,comp_BR,comp_dst,1,-1);
	multiply(comp_dst,comp_GR,comp_dst,1,-1);
	multiply(comp_dst,comp_I1,comp_dst,1,-1);
//	multiply(comp_I1,comp_I1,comp_dst,1,-1);
	multiply(comp_dst,comp_I2,comp_dst,1,-1);

	threshold(comp_dst, comp_dst, 0, 1, CV_THRESH_BINARY);

	comp_dst.convertTo(comp_dst,CV_8U);

	Mat new_Color[3],frame_det;
	multiply(comp_dst,colorChannels[0],new_Color[0],1,-1);
	multiply(comp_dst,colorChannels[1],new_Color[1],1,-1);
	multiply(comp_dst,colorChannels[2],new_Color[2],1,-1);
	merge(new_Color,3,frame_det);

	//cvtColor(frame_det, frame_det, COLOR_BGR2GRAY);
	return frame_det;
}


//smoke: local smoothness check
double foreGround::LS(Mat srcImg,Mat bgdImg)
{
	srcImg.convertTo(srcImg,CV_32F);
	bgdImg.convertTo(bgdImg,CV_32F);
	double srcImg_mean;
	Mat srcImg_devia;
	srcImg_mean=mean(srcImg)[0];
	subtract(srcImg,srcImg_mean,srcImg_devia);

	double bgdImg_mean;
	Mat bgdImg_devia;
	bgdImg_mean=mean(bgdImg)[0];
	subtract(bgdImg,bgdImg_mean,bgdImg_devia);

	Mat srcImg_dot;
	Scalar srcImg_dotSum;
	Mat bgdImg_dot;
	Scalar bgdImg_dotSum;
	Mat srcbgdImg_dot;
	Scalar srcbgdImg_dotSum;
	multiply(srcImg_devia,srcImg_devia,srcImg_dot,1,-1);
	srcImg_dotSum=sum(srcImg_dot);
	multiply(bgdImg_devia,bgdImg_devia,bgdImg_dot,1,-1);
	bgdImg_dotSum=sum(bgdImg_dot);
	multiply(srcImg_devia,bgdImg_devia,srcbgdImg_dot,1,-1);
	srcbgdImg_dotSum=sum(srcbgdImg_dot);
	double corr;
	corr=srcbgdImg_dotSum[0]/sqrt(srcImg_dotSum[0]*bgdImg_dotSum[0]);

	return corr;
}

//summing up the squared contribution coming from every coefficient imagewavelet 
double foreGround::waveletEnergy(Mat srcImage, int layer)
{
	
	int row_half=srcImage.rows/2+1;
	int col_half=srcImage.cols/2+1;
	Mat zerosLL(row_half,col_half,CV_32F,Scalar(0));
		srcImage.convertTo(srcImage,CV_32F);
		IplImage img = srcImage.operator _IplImage();  
		DWT(&img,layer);
		Mat imgMat(&img);	
		Mat imgMat2;
		//imgMat.convertTo(imgMat2,CV_8U);
		//		imshow("wavelet_original",imgMat2);
		//waitKey(10);
		Mat imageROI=imgMat(Rect(0,0,col_half,row_half));
		addWeighted(imageROI,0,zerosLL,1,0,imageROI);

		//imgMat.convertTo(imgMat2,CV_8U);
		//imshow("wavelet",imgMat2);
		//waitKey(10);

		Mat imgMat_square;
		multiply(imgMat,imgMat,imgMat_square,1,-1);
		Scalar waveletEnergy=sum(imgMat_square);
		return waveletEnergy[0];
}


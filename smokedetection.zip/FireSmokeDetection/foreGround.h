#include <iostream>
#include <fstream>
#include <vector>
#include "opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <math.h>
#include <opencv2\legacy\legacy.hpp> 
#include <vector>
#include "swavelet.h"

using namespace cv;
using namespace std;

//ͼ���ṹ��
struct FraRIO
{
	Mat frameRIO;
	int point_x;
	int point_y;
	bool RIO_flag;

};

class foreGround
{
public:
	//background initialization and updating
	Mat averageFrame(CvCapture *capture, const int frameStart, const int frameEnd);
	Mat updateBackground(Mat curFrame, Mat backgroundModel, const double coef); 
	Mat frameCrop(Mat imgSource, vector<CvRect> rects,int blk_widht,int blk_height);
	
	// colour filtering by HSV,RGB and YCrCb model
	Mat ColorDet(Mat srcImg);	
	void ImgMean(float& c1, float& c2, float& c3, Mat pImg);
	
	//�Ҷȼ��
	void GrayDet(Mat srcImg,int grayThres);  

	//image division into blocks
	vector<FraRIO>  DivFra(Mat &image, int width, int height);  
	Mat  mergeDivFra(vector<FraRIO> frame_RIO, int width, int height);

	//count the nunbers of the binary pixel greater than zero 
	//�����ֵͼ���ش���0�ĸ���
	int bSums(Mat src);  
	void draw_Histogram(MatND &hist,int scale);
	
	//smoke detection
	//local smoothness for smoke detection
	double LS(Mat srcImg, Mat bgdImg); 
	Mat smokeColorDet(Mat srcImg);

	//summing up the squared contribution coming from every coefficient imagewavelet 
	double waveletEnergy(Mat srcImage, int layer);
private:

};
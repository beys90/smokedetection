#include <iostream>
#include <fstream>
#include <string> 
#include <stdio.h>
#include <cv.h>
#include "highgui.h"
#include "LBP.h"
#include "character.h"
#include "foreGround.h"
#include "CCL.h"
#include <time.h>
#include "swavelet.h"
#include "GLCM.h"
#include "windows.h"

#include "opencv2/opencv.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <math.h>
#include <vector>
#include "WriteData.h"
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/ml/ml.hpp>


using namespace std;
using namespace cv;

#define CELL_SIZE   4
#define PI 3.1415
#define fireFreq 3
#define blk_width 40
#define blk_height 40
#define fireBlk_minWidth 20
#define fireBlk_minHeight 20
#define ALPHA 0.05
#define LAYER 1
#define WAVELET_MAX 0.9
#define WAVELET_MIN 0.3
#define LS_thres 0.9			//��ǰ���뱳��������ϵ����ֵ
#define LS1_thres 0.4		    //��ǰ���봿���������ϵ����ֵ


//��ͨ��
void darklightChannel(Mat src,Mat dark,Mat light)
{
	Vec3b intensity;
	for (int m = 0; m<src.rows; m++)
	{
		for (int n = 0; n<src.cols; n++)
		{
			intensity = src.at<Vec3b>(m, n);
			dark.at<uchar>(m, n) = min(min(intensity.val[0], intensity.val[1]), intensity.val[2]);
			light.at<uchar>(m, n) = max(max(intensity.val[0], intensity.val[1]), intensity.val[2]);
		}
	}
}

Mat darkChannel(Mat src)  
{  
    Mat rgbmin = Mat::zeros(src.rows, src.cols, CV_8UC1);  
    Mat dark = Mat::zeros(src.rows, src.cols, CV_8UC1);  
    Vec3b intensity;  
  
    for (int m = 0; m<src.rows; m++)  
    {  
        for (int n = 0; n<src.cols; n++)  
        {  
            intensity = src.at<Vec3b>(m, n);  
            rgbmin.at<uchar>(m, n) = min(min(intensity.val[0], intensity.val[1]), intensity.val[2]); 			
        }  
    }    
    ////ģ��ߴ�  
    //int scale = 3;  
    ////�߽�����  
    //int radius = (scale - 1) / 2;  
    //Mat border;  
    ////����Ҫ����Сֵ����������ı߽�����ø��Ʊ߽����  
    //copyMakeBorder(rgbmin, border, radius, radius, radius, radius, BORDER_REPLICATE);  
    ////��Сֵ�˲�  
    //for (int i = 0; i < src.cols; i++)  
    //{  
    //    for (int j = 0; j < src.rows; j++)  
    //    {  
    //        //ѡȡ��Ȥ����  
    //        Mat roi;  
    //        roi = border(Rect(i, j, scale, scale));    
    //        //����Ȥ�������Сֵ  
    //        double minVal = 0; double maxVal = 0;  
    //        Point minLoc = 0; Point maxLoc = 0;  
    //        minMaxLoc(roi, &minVal, &maxVal, &minLoc, &maxLoc, noArray());    
    //        dark.at<uchar>(Point(i, j)) = (uchar)minVal;  
    //    }  
    //}  
	return rgbmin;
}  

Mat lightChannel(Mat src)
{
	Mat rgbmin = Mat::zeros(src.rows, src.cols, CV_8UC1);
	Mat dark = Mat::zeros(src.rows, src.cols, CV_8UC1);
	Vec3b intensity;

	for (int m = 0; m<src.rows; m++)
	{
		for (int n = 0; n<src.cols; n++)
		{
			intensity = src.at<Vec3b>(m, n);
			rgbmin.at<uchar>(m, n) = max(max(intensity.val[0], intensity.val[1]), intensity.val[2]);
		}
	}
	////ģ��ߴ�  
	//int scale = 3;  
	////�߽�����  
	//int radius = (scale - 1) / 2;  
	//Mat border;  
	////����Ҫ����Сֵ����������ı߽�����ø��Ʊ߽����  
	//copyMakeBorder(rgbmin, border, radius, radius, radius, radius, BORDER_REPLICATE);  
	////��Сֵ�˲�  
	//for (int i = 0; i < src.cols; i++)  
	//{  
	//    for (int j = 0; j < src.rows; j++)  
	//    {  
	//        //ѡȡ��Ȥ����  
	//        Mat roi;  
	//        roi = border(Rect(i, j, scale, scale));    
	//        //����Ȥ�������Сֵ  
	//        double minVal = 0; double maxVal = 0;  
	//        Point minLoc = 0; Point maxLoc = 0;  
	//        minMaxLoc(roi, &minVal, &maxVal, &minLoc, &maxLoc, noArray());    
	//        dark.at<uchar>(Point(i, j)) = (uchar)minVal;  
	//    }  
	//}  
	return rgbmin;
}

uchar light(vector<uchar> inputIamgeMax)  
{  
    uchar maxA=0;  
    for (int i = 0; i < inputIamgeMax.size() - 1; i++)  
    {  
          
        if (maxA < inputIamgeMax[i + 1])  
        {  
            maxA = inputIamgeMax[i + 1];  
        }  
    }  
    return maxA;  
}

//�Գ���Ϊn������a����ͳ�ƣ�ͳ����ƽ��ֵaver������vari����׼��stdDev
void comPute(double a[], int n, double *aver, double *stdDev){
	int i;
	double *p;
	double aver2 = 0;
	*aver = 0.0;
	for (p = a + (n - 1); p >= a; --p){
		*aver += *p;//�ۼӸ�Ԫ��
		aver2 += (*p)*(*p);//�ۼӸ�Ԫ�ص�ƽ��
	}
	*aver /= n;//��ƽ��ֵ
	aver2 /= n;//��ƽ����ƽ��ֵ
	double vari = aver2 - (*aver)*(*aver);//���㷽��
	*stdDev = sqrt(vari);//�����׼��
}

void main()	
{
	/*��ȡ��Ƶ*/
	const char* videoName = "camera//20170609161751508.mp4";

	int pos_index=400;
	int Flag = 51;
	CvCapture* capture;
	IplImage* src;

	Mat img;	
	double blkRatio_thres=0.05; //frame identify:ratio bigger than the threshold is identified as smoke
	double blkRatio_tem_thres=400;  //frame difference identify: block ratio bigger than the threshold is identified as fire
	int delay = 1;
	int numFrames = 12000;   //��Ƶ��֡�� 
	Mat frame = Mat::zeros(360,480,CV_8UC3 );  //resize֮���ͼƬ�ߴ�Ϊ360*480
	Mat zeroBlk(blk_height,blk_width, CV_8U,cv::Scalar(0));
	Mat frameGrayBlk(blk_height,blk_width,CV_8U,cv::Scalar(0));
	Mat frameBlk_resize(blk_height,blk_width,CV_8U,cv::Scalar(0));
	
	foreGround foreground;

	//���嵱ǰ֡����ʱ֡
	Mat frameProGray;
	Mat frameGray;
	Mat frameBlkTem(blk_height,blk_width, CV_8U,cv::Scalar(0,0,0));  //ColorBlk
	Mat tem_frameBlk(blk_height,blk_width, CV_8U,cv::Scalar(0));     //tem_frame Block

	//����ǰһ֡�͵�ǰ֡�ָ��Ľṹ������
	vector<FraRIO> frameGray_RIO;
	vector<FraRIO> frameProGray_RIO;
	vector<FraRIO> frameBinary_RIO;
	vector<FraRIO> tem_frame_RIO;
	vector<FraRIO> frame_RIO;
	vector<FraRIO> frameFilterGray_RIO;
	vector<FraRIO> frameFilter_RIO;

	// �Ľ�
	int DivCell = 10;
	vector<CvRect> smokeRect;

	int conFra = 0;
	double areaVal[5];
	double perVal[5];
	
	bool flag =false;
	int fireAlarm=0;   // when fireAlarm==freFreq;
	
	//backgroundModel initialization
	Mat backgroundModel;

	int h_bins = 32, s_bins = 16;
	int bins = 40;
	int validBlk = 0;

	IplImage* resentFrame;

	Mat frameFilter;
	
	numFrames=12000;
	int camera = 0;	
	int posIndex = 0;
	
	if (camera)
	{
		//��������ͷ
		capture = cvCreateCameraCapture(0);
		Sleep(2000);
		src = cvQueryFrame(capture);
		img = Mat(src);
	}
	else
	{
		//��ȡ��Ƶ
		capture = cvCreateFileCapture(videoName);
		cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES, 55);
		img = cvRetrieveFrame(capture);
	}	

	resize(img, frame, frame.size());
    cvtColor(frame,frameGray,COLOR_BGR2GRAY);
	cvtColor(frame, backgroundModel,CV_BGR2GRAY);
    backgroundModel.convertTo(backgroundModel,CV_8U);

	int posFlag = 0;
	for (int i=Flag;i<numFrames;i++ )
	{		
		if (camera)
		{
			//��������ͷ
			src = cvQueryFrame(capture);
			img = Mat(src);
		}
		else
		{
			//��ȡ��Ƶ
			cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES, i);
			img = cvRetrieveFrame(capture);
		}		

		/*ͼ�񽵲���*/
		resize(img, frame, frame.size());	
		vector<CvRect> rects;    //store fire regions
				
		cvtColor(frame,frameGray,COLOR_BGR2GRAY);

		//ǰһ֡�͵�ǰ֡�ָ������ҶȱȽϣ��Կ����������SVM�ж�
		if (flag == false)
		{
			frameProGray = frameGray.clone();			
			flag=true;
		}
		else
		{		
			//��ǰ֡��ǰһ֡����,������ʱ֡
			Mat tempFra;
			absdiff(frameGray, frameProGray, tempFra);

			//��ֵ����ǰ��֡��Ҷ�С���趨ֵ��Ϊ����������ǰ�Ҷ���Ϊ80
			threshold(tempFra, tempFra, 10, 0, CV_THRESH_TOZERO_INV);   //����10Ϊ������
			threshold(tempFra, tempFra, 5, 1, CV_THRESH_BINARY);        //С��5Ϊ������	
			imshow("Real-time tempFra Detection", tempFra * 250);

			/*Mat DarkRes = darkChannel(frame);
			Mat LightRes = lightChannel(frame);*/
			Mat DarkRes = Mat::zeros(frame.rows, frame.cols, CV_8UC1);
			Mat LightRes = Mat::zeros(frame.rows, frame.cols, CV_8UC1);
			darklightChannel(frame,DarkRes,LightRes);
			//���㰵ͨ��
			threshold(DarkRes, DarkRes, 50, 0, CV_THRESH_TOZERO);
			Mat tempRes;
			absdiff(DarkRes, LightRes, tempRes);
			multiply(tempRes, tempFra, tempRes, 1, -1);
			threshold(tempRes, tempRes, 10, 0, CV_THRESH_TOZERO_INV);
			threshold(tempRes, tempRes, 5, 1, CV_THRESH_BINARY);	

			//imshow("Real-time DarkRes Detection", DarkRes);
			//imshow("Real-time LightRes Detection", LightRes);
			imshow("Real-time tempRes Detection", tempRes * 100);
			cvWaitKey(1);
			//DivCell = 5;
			tem_frame_RIO = foreground.DivFra(tempRes, DivCell, DivCell);
			int number = 0;
			vector<FraRIO>::iterator it_tem_frame = tem_frame_RIO.begin();
			Mat frameline = Mat::zeros(360 / DivCell, 480 / DivCell, CV_8UC1);

			while (it_tem_frame != tem_frame_RIO.end())
			{
				number = countNonZero(it_tem_frame->frameRIO);
				if (number>5 && number<50)
					frameline.at<uchar>(it_tem_frame->point_y / DivCell, it_tem_frame->point_x / DivCell) = 1;
				it_tem_frame++;
			}

			Mat element;
			element = getStructuringElement(MORPH_RECT, Size(3, 3));
			dilate(frameline, frameline, element);    //���� 
			imshow("Real-time Temp Detection", frameline * 250);

			//����frameline�����ƶ�
			int num = countNonZero(frameline);
			//�ҳ����������������	
			resentFrame = &IplImage(frameline);
			CvSeq *seq = 0;
			CvMemStorage * storage = cvCreateMemStorage(0);
			cvFindContours(resentFrame, storage, &seq, sizeof(CvContour), CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE);
			CvRect rect;

			//���FireRect;
			vector<CvRect>().swap(smokeRect);
			int validBlk = 0;

			for (; seq != 0; seq = seq->h_next)
			{
				rect = cvBoundingRect(seq, 0);
				if (rect.width >= 4 && rect.width <= 20 && rect.height >= 4 && rect.height <= 20) //��������ϴ��������������Ϊ0
				{
					Mat rectFrame = frameline(Rect(rect.x, rect.y, rect.width - 1, rect.height - 1));

					//�����ܳ�\���
					double S = cvContourArea(seq, CV_WHOLE_SEQ);
					double L = cvArcLength(seq, CV_WHOLE_SEQ, -1);

					areaVal[conFra] = S;
					perVal[conFra] = L;
					conFra++;
					conFra = conFra % 5;
					double averS = 1, averL = 1;
					double stdDevS = 0, stdDevL = 0;
					comPute(areaVal, 5, &averS, &stdDevS);
					comPute(perVal, 5, &averL, &stdDevL);
					cout << "����:" << averS / averL << '    ' << "���" << stdDevS / averS << ' ' << stdDevL / averL << endl;

					//if (stdDevS / averS<0.15 && stdDevL / averL<0.15 && averS / averL>1.5)
					if (stdDevS/averS<0.30 && stdDevL/averL<0.30 && averS/averL>0.9)
					{
						smokeRect.push_back(Rect(rect.x*DivCell, rect.y*DivCell, (rect.width - 1)*DivCell, (rect.height - 1)*DivCell));
						rectangle(frame, cvPoint(rect.x*DivCell, rect.y*DivCell), cvPoint((rect.x + rect.width)*DivCell, (rect.y + rect.height)*DivCell), Scalar(0, 255, 0), 3, 1, 0);//�ܹ�ʵʱ��ʾ�˶�����								
						validBlk = 1;
						posIndex++;
						break;
					}
				}
			}

			if (validBlk != 0)
			{
				fireAlarm++;
			}
			else
			{
				fireAlarm --;
				if (fireAlarm < 0)
					fireAlarm = 0;
			}
			if (fireAlarm >= fireFreq)
			{
				cout << "Smoke Alarm" << endl;
				fireAlarm = 0;
			}
			imshow("Real-time Smoke Detection", frame);
			cvWaitKey(1);			
			if (validBlk)
			{
				int ii = 0;
			}
			cout << posIndex << " / " << i << endl;
			//���±���,����֡����
			frameProGray = frameGray.clone();		
		}		
	}
	waitKey(0);
}

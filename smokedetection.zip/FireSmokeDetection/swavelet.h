#ifndef _SWAVELET_H_
#define _SWAVELET_H_

#include "cv.h"
#include <stdlib.h>
#include <math.h>

void DWT(IplImage *pImage, int nLayer);
void IDWT(IplImage *pImage, int nLayer);

#endif